import React from 'react';
import {
  Link, Routes, Route, useLocation,
} from 'react-router-dom';
import { FiArchive, FiBook } from 'react-icons/fi';

import Navigation from './components/Navigation';
import HomePage from './pages/HomePage';
import ArchivePage from './pages/ArchivePage';
import DetailPage from './pages/DetailPage';
import AddPage from './pages/AddPage';
import NotFoundPage from './pages/NotFoundPage';

function App() {
  const location = useLocation();
  return (
    <div className="app-container">
      <Navigation />
      <main id="main">
        <section className="sidenav-menu">
          <Link to="/" className={`sidenav-menu__item ${location.pathname === '/' && 'active'}`}>
            <FiBook />
            <p>Catatan</p>
          </Link>
          <Link to="/archives" className={`sidenav-menu__item ${location.pathname === '/archives' && 'active'}`}>
            <FiArchive />
            <p>Arsip</p>
          </Link>
        </section>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/archives" element={<ArchivePage />} />
          <Route path="/notes/:id" element={<DetailPage />} />
          <Route path="/notes/new" element={<AddPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
