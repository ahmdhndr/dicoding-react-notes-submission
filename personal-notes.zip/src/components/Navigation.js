import React from 'react';
import { Link } from 'react-router-dom';
import { FiMenu } from 'react-icons/fi';

function Navigation() {
  function onHideMenuHandler() {
    const mainTag = document.getElementById('main');
    mainTag.classList.toggle('hide');
  }

  return (
    <header>
      <div className="menu">
        <FiMenu onClick={onHideMenuHandler} />
      </div>
      <h1>
        <Link to="/">Notes App</Link>
      </h1>
    </header>
  );
}

export default Navigation;
