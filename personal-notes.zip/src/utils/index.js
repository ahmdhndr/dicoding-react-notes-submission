const showFormattedDate = (date) => {
  const options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  };
  if (!date) {
    return null;
  }
  return new Date(date).toLocaleDateString('id-ID', options);
};

export { showFormattedDate };
